/* app.js — Command Center interactions, numbered blocks. */

// ---- 0. Status marks: pending / running / done / failed ----
const SM_C = 2 * Math.PI * 9;
function createStatus(label, status = 'pending', progress = null) {
  const el = document.createElement('span');
  el.className = 'status-mark';
  el.innerHTML =
    `<svg class="status-mark__glyph" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">` +
    `<circle class="status-mark__track" cx="12" cy="12" r="9" transform="rotate(-90 12 12)"/>` +
    `<circle class="status-mark__ring" cx="12" cy="12" r="9" transform="rotate(-90 12 12)"/>` +
    `<path class="status-mark__check" d="M7.5 12.25 10.5 15.25 16.75 8.75" pathLength="1"/>` +
    `<path class="status-mark__cross" d="M8.5 8.5 15.5 15.5M15.5 8.5 8.5 15.5" pathLength="1"/>` +
    `</svg><span class="status-mark__label">${label}<span class="status-mark__strike"></span></span>`;
  setStatus(el, status, label, progress);
  return el;
}
function setStatus(el, status, label = null, progress = null) {
  el.dataset.status = status;
  const ring = el.querySelector('.status-mark__ring');
  if (status === 'running') {
    if (progress != null) {
      el.removeAttribute('data-indeterminate');
      const p = Math.min(1, Math.max(0, progress));
      ring.setAttribute('stroke-dasharray', `${(p * SM_C).toFixed(1)} ${SM_C.toFixed(1)}`);
    } else {
      el.setAttribute('data-indeterminate', '');
      ring.removeAttribute('stroke-dasharray');
    }
  } else {
    el.removeAttribute('data-indeterminate');
  }
  if (label !== null) el.querySelector('.status-mark__label').childNodes[0].textContent = label;
}

// ---- 2. Toast popup (SwipeToast style): burning fuse, swipe-down, action button ----
let toastStack = null;
function toast(title, desc = '', actionLabel = '', onAction = null) {
  if (!toastStack) {
    toastStack = document.createElement('div');
    toastStack.className = 'st-stack';
    document.body.appendChild(toastStack);
  }
  const el = document.createElement('div');
  el.className = 'st';
  el.tabIndex = 0;
  el.setAttribute('role', 'status');
  el.innerHTML =
    `<div class="st__row"><div class="st__body">` +
    `<div class="st__title">${title}</div>` +
    (desc ? `<div class="st__desc">${desc}</div>` : '') +
    `</div>` +
    (actionLabel ? `<button class="st__action">${actionLabel}</button>` : '') +
    `</div><i class="st__fuse"></i>`;
  toastStack.appendChild(el);

  const DUR = 5000;
  let remaining = DUR, started = Date.now(), timer = null, paused = false;

  function arm() { started = Date.now(); timer = setTimeout(dismiss, remaining); }
  function dismiss() {
    clearTimeout(timer);
    el.classList.add('leaving');
    setTimeout(() => el.remove(), 300);
  }
  el.addEventListener('mouseenter', () => {
    if (paused) return;
    paused = true;
    clearTimeout(timer);
    remaining -= Date.now() - started;
    el.querySelector('.st__fuse').style.animationPlayState = 'paused';
  });
  el.addEventListener('mouseleave', () => {
    if (!paused) return;
    paused = false;
    arm();
    el.querySelector('.st__fuse').style.animationPlayState = 'running';
  });
  const btn = el.querySelector('.st__action');
  if (btn) btn.addEventListener('click', () => { if (onAction) onAction(); dismiss(); });
  let dy = 0, dragging = false, startY = 0;
  el.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    dragging = true; startY = e.clientY; dy = 0;
    el.classList.add('dragging');
    el.style.transition = 'none';
    try { el.setPointerCapture(e.pointerId); } catch {}
  });
  el.addEventListener('pointermove', e => {
    if (!dragging) return;
    dy = Math.max(-24, e.clientY - startY);
    el.style.transform = `translateY(${dy}px)`;
  });
  const release = () => {
    if (!dragging) return;
    dragging = false;
    el.classList.remove('dragging');
    el.style.transition = '';
    if (dy > 48) dismiss(); else el.style.transform = '';
  };
  el.addEventListener('pointerup', release);
  el.addEventListener('pointercancel', release);
  el.addEventListener('keydown', e => { if (e.key === 'Escape') dismiss(); });
  arm();
}

// ---- 3. Beep sound using Web Audio API ----
function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.frequency.value = 880;
    gain.gain.value = 0.08;
    osc.start();
    setTimeout(() => osc.stop(), 250);
  } catch (e) { /* audio blocked until user clicks */ }
}

// ---- 1. Auto-refresh dashboard numbers every 5 seconds ----
let lastPending = 0;
async function refreshStats() {
  const sync = document.getElementById('syncMark');
  try {
    const res = await fetch('/api/stats');
    const d = await res.json();
    for (const [id, value] of Object.entries(d)) {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    }
    const badge = document.getElementById('navPending');
    if (badge) badge.textContent = d.pendingCount > 0 ? d.pendingCount : '';
    if (d.pendingCount > lastPending && lastPending !== 0) {
      if (localStorage.getItem('notifyApprovals') !== 'off') {
        beep();
        toast('⚠️ Your agent needs approval!', 'Open Approvals to decide', 'Open',
              () => { window.location.href = '/approvals'; });
      }
    }
    lastPending = d.pendingCount;
    if (sync) setStatus(sync, 'done', 'Live — synced with agent');
  } catch (e) {
    if (sync) setStatus(sync, 'failed', 'Agent unreachable — retrying…');
  }
}
if (localStorage.getItem('autoRefresh') !== 'off') setInterval(refreshStats, 5000);
refreshStats();

// ---- 4. Approve / Reject buttons (event delegation) ----
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-decide]');
  if (!btn) return;
  btn.disabled = true;
  const card = btn.closest('.approval-card');
  const actions = btn.closest('.approval-actions');
  let sm = null;
  if (card) {
    actions.style.visibility = 'hidden';
    sm = createStatus('Notifying agent…', 'running');
    card.appendChild(sm);
  }
  const res = await fetch(`/api/approvals/${btn.dataset.id}/${btn.dataset.decide}`, { method: 'POST' });
  const data = await res.json();
  if (data.ok) {
    if (sm) setStatus(sm, 'done', 'Agent notified');
    toast(btn.dataset.decide === 'approved' ? '✔ Approved' : '✘ Rejected',
          'Agent notified — workflow resumed');
    setTimeout(() => location.reload(), 900);
  } else {
    if (sm) { sm.remove(); actions.style.visibility = ''; }
    toast('Error: ' + (data.error || 'try again'));
    btn.disabled = false;
  }
});

// ---- 5. Conversation search ----
const searchBox = document.getElementById('searchBox');
if (searchBox) {
  searchBox.addEventListener('input', () => {
    const q = searchBox.value.toLowerCase();
    document.querySelectorAll('.swipe-row[data-text]').forEach(m => {
      m.style.display = (m.dataset.text || '').includes(q) ? '' : 'none';
    });
  });
}

// ---- 6. Dark / light mode toggle ----
const themeBtn = document.getElementById('themeToggle');
if (themeBtn) {
  if (localStorage.getItem('theme') === 'light') document.body.classList.add('light');
  themeBtn.addEventListener('click', () => {
    document.body.classList.toggle('light');
    localStorage.setItem('theme', document.body.classList.contains('light') ? 'light' : 'dark');
    themeBtn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
  });
  themeBtn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
}

// ---- 7. Flip cards ----
document.querySelectorAll('.flip-card').forEach(card => {
  card.addEventListener('click', () => card.classList.toggle('flipped'));
  card.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      card.classList.toggle('flipped');
    }
  });
});

// ---- 8. Branched sidebar menu: fold, tree lines, sliding marker ----
const sideNav = document.getElementById('sideNav');
if (sideNav) {
  const ROW_H = 36, PAD = 6, TRUNK = 14, R = 10, END_X = 32, MARK = 16;
  const marker = sideNav.querySelector('.branched-menu__marker');

  function drawTree(section) {
    const tree = section.querySelector('.branched-menu__tree');
    if (!tree) return;
    const svg = tree.querySelector('.branched-menu__lines');
    const items = [...tree.querySelectorAll('.branched-menu__item')];
    const n = items.length;
    const bodyH = PAD * 2 + n * ROW_H;
    tree.style.height = bodyH + 'px';
    svg.setAttribute('viewBox', `0 0 40 ${bodyH}`);
    svg.style.height = bodyH + 'px';
    const rowY = k => PAD + k * ROW_H + ROW_H / 2;

    let base = `M ${TRUNK} 0 V ${rowY(n - 1) - R}`;
    let reach = '', reachLen = 0;
    items.forEach((it, k) => {
      base += ` M ${TRUNK} ${rowY(k) - R} A ${R} ${R} 0 0 0 ${TRUNK + R} ${rowY(k)} H ${END_X}`;
      if (it.hasAttribute('data-active')) {
        reach = `M ${TRUNK} 0 V ${rowY(k) - R} A ${R} ${R} 0 0 0 ${TRUNK + R} ${rowY(k)} H ${END_X}`;
        reachLen = rowY(k) - R + (Math.PI * R) / 2 + (END_X - TRUNK - R);
      }
    });
    const dash = Math.max(reachLen, 1);
    svg.innerHTML = `<path class="branched-menu__base" d="${base}"/>` +
      (reach ? `<path class="branched-menu__reach" d="${reach}" style="stroke-dasharray:${dash};stroke-dashoffset:${dash}"/>` : '');
    if (reach) requestAnimationFrame(() => requestAnimationFrame(() => {
      const p = svg.querySelector('.branched-menu__reach');
      if (p) p.style.strokeDashoffset = '0';
    }));
  }

  function placeMarker() {
    const act = sideNav.querySelector('.branched-menu__item[data-active]');
    const visible = act && act.closest('.branched-menu__section').hasAttribute('data-open');
    if (act && visible) {
      const navR = sideNav.getBoundingClientRect();
      const r = act.getBoundingClientRect();
      marker.style.top = (r.top - navR.top + sideNav.scrollTop + (r.height - MARK) / 2) + 'px';
      marker.setAttribute('data-on', '');
    } else {
      marker.removeAttribute('data-on');
    }
  }

  sideNav.querySelectorAll('.branched-menu__section').forEach(sec => {
    const head = sec.querySelector('.branched-menu__head');
    if (head && head.hasAttribute('data-fold')) {
      head.addEventListener('click', () => {
        const isOpen = sec.hasAttribute('data-open');
        if (isOpen) sec.removeAttribute('data-open');
        else { sec.setAttribute('data-open', ''); drawTree(sec); }
        head.setAttribute('aria-expanded', String(!isOpen));
        setTimeout(placeMarker, 50);
      });
    }
    if (sec.hasAttribute('data-open')) drawTree(sec);
  });

  sideNav.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
      const url = btn.getAttribute('data-nav');
      if (url && url !== '#') window.location.href = url;
    });
  });

  window.addEventListener('resize', placeMarker);
  placeMarker();
}

// ---- 9. Customer order folders ----
document.querySelectorAll('.folder-float').forEach(folder => {
  const trigger = folder.querySelector('.folder-float__trigger');
  const pills = [...folder.querySelectorAll('.folder-float__item')];
  if (!trigger) return;

  const jitter = i => {
    const x = Math.sin(i * 12.9898 + 4.1414) * 43758.5453;
    return x - Math.floor(x);
  };

  function layoutPills() {
    const spread = 190, lift = 32, gap = 10, rowH = 46;
    const sizes = pills.map(el => el.offsetWidth);
    const rows = [];
    let row = [], w = 0;
    pills.forEach((el, i) => {
      if (row.length && w + gap + sizes[i] > spread * 2) { rows.push({ row, w }); row = []; w = 0; }
      row.push(i);
      w += (row.length > 1 ? gap : 0) + sizes[i];
    });
    if (row.length) rows.push({ row, w });

    const pos = [];
    rows.forEach((r, ri) => {
      let x = -r.w / 2;
      const shift = (ri % 2 ? 1 : -1) * Math.min(14, spread * 0.08);
      r.row.forEach(i => {
        const j = jitter(i);
        pos[i] = { x: x + sizes[i] / 2 + shift + (j - 0.5) * 8,
                   y: -lift - ri * rowH - j * 8,
                   r: 8 * (j * 2 - 1) };
        x += sizes[i] + gap;
      });
    });
    pills.forEach((el, i) => {
      el.style.setProperty('--x', pos[i].x.toFixed(1) + 'px');
      el.style.setProperty('--y', pos[i].y.toFixed(1) + 'px');
      el.style.setProperty('--r', pos[i].r.toFixed(1) + 'deg');
    });
  }

  trigger.addEventListener('click', () => {
    const isOpen = folder.hasAttribute('data-open');
    if (isOpen) folder.removeAttribute('data-open');
    else { layoutPills(); folder.setAttribute('data-open', ''); }
    trigger.setAttribute('aria-expanded', String(!isOpen));
  });
  folder.addEventListener('keydown', e => {
    if (e.key === 'Escape') { folder.removeAttribute('data-open'); trigger.setAttribute('aria-expanded', 'false'); }
  });
});

// ---- 10. Voice message players ----
document.querySelectorAll('.voice-msg').forEach(vm => {
  const btn = vm.querySelector('.voice-msg__btn');
  const fill = vm.querySelector('.voice-msg__progress');
  const dur = vm.querySelector('.voice-msg__dur');
  let audio = null;

  btn.addEventListener('click', () => {
    if (!audio) {
      audio = new Audio(vm.dataset.src);
      audio.addEventListener('timeupdate', () => {
        if (audio.duration) {
          fill.style.width = (audio.currentTime / audio.duration * 100) + '%';
          const left = Math.max(0, Math.round(audio.duration - audio.currentTime));
          dur.textContent = left + 's';
        }
      });
      audio.addEventListener('ended', () => {
        vm.classList.remove('playing');
        fill.style.width = '0%';
        dur.textContent = vm.dataset.dur + 's';
      });
    }
    if (vm.classList.contains('playing')) {
      audio.pause();
      vm.classList.remove('playing');
    } else {
      audio.play().catch(() => toast('Audio failed to load'));
      vm.classList.add('playing');
    }
  });
});

// ---- 12. GlideSelect ----
document.querySelectorAll('.glide-select').forEach(gs => {
  const trigger = gs.querySelector('.glide-select__trigger');
  const label = gs.querySelector('.glide-select__label');
  const menu = gs.querySelector('.glide-select__menu');
  const pill = gs.querySelector('.glide-select__pill');
  const rows = [...gs.querySelectorAll('.glide-select__option')];
  const STEP = 31;
  let active = null;

  function movePill(i, instant = false) {
    if (i === null) { pill.style.opacity = '0'; return; }
    pill.style.transitionDuration = instant ? '0ms' : '';
    pill.style.transform = `translateY(${i * STEP}px)`;
    pill.style.opacity = '1';
  }
  function open() {
    gs.dataset.open = '';
    trigger.setAttribute('aria-expanded', 'true');
    menu.dataset.state = 'open';
    const sel = rows.findIndex(r => r.getAttribute('aria-selected') === 'true');
    movePill(sel >= 0 ? sel : null, true);
  }
  function close() {
    delete gs.dataset.open;
    trigger.setAttribute('aria-expanded', 'false');
    menu.dataset.state = 'closed';
    active = null;
  }

  trigger.addEventListener('click', e => {
    e.stopPropagation();
    gs.hasAttribute('data-open') ? close() : open();
  });
  document.addEventListener('pointerdown', e => {
    if (!gs.contains(e.target)) close();
  });

  rows.forEach((row, i) => {
    row.addEventListener('pointerenter', () => { active = i; movePill(i); });
    row.addEventListener('click', () => {
      rows.forEach(r => r.setAttribute('aria-selected', 'false'));
      row.setAttribute('aria-selected', 'true');
      label.textContent = row.querySelector('.glide-select__name').textContent;
      label.removeAttribute('data-empty');
      gs.dataset.swap = '';
      setTimeout(() => delete gs.dataset.swap, 200);
      close();
      const url = row.dataset.url;
      if (url && url !== '#') {
        toast('Preparing ' + label.textContent + '…');
        window.open(url, '_blank');
      }
      gs.dispatchEvent(new CustomEvent('gs:change', { detail: { value: row.dataset.value } }));
    });
  });

  gs.tabIndex = 0;
  gs.addEventListener('keydown', e => {
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (!gs.hasAttribute('data-open')) { open(); return; }
      active = active === null
        ? 0
        : Math.min(rows.length - 1, Math.max(0, active + (e.key === 'ArrowDown' ? 1 : -1)));
      movePill(active, true);
    }
    if ((e.key === 'Enter' || e.key === ' ') && gs.hasAttribute('data-open') && active !== null) {
      e.preventDefault();
      rows[active].click();
    }
  });
});

// ---- 13. SwipeRow: drag left to reveal quick actions, full swipe commits ----
document.querySelectorAll('.swipe-row').forEach(row => {
  const surface = row.querySelector('.swipe-row__surface');
  if (!surface) return;
  const A = 80;
  const nActions = row.querySelectorAll('.swipe-row__action').length;
  const D = A * nActions;
  let x = 0, open = false, dragging = false, startX = 0, baseX = 0;

  const commitPoint = () => Math.max(0.6 * row.offsetWidth, D + 40);

  function settle(target, commit = false) {
    dragging = false;
    row.removeAttribute('data-dragging');
    surface.style.transition = '';
    x = target;
    open = target !== 0;
    surface.style.transform = target ? `translateX(${target}px)` : '';
    if (commit) collapse();
  }
  function collapse() {
    row.style.height = row.offsetHeight + 'px';
    row.dataset.phase = 'collapsing';
    setTimeout(() => row.remove(), 220);
  }
  async function doDelete() {
    try {
      await fetch(`/api/conversations/${row.dataset.id}`, { method: 'DELETE' });
      toast('Message deleted');
    } catch { toast('Delete failed', 'Refresh and try again'); }
  }

  surface.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    dragging = true; startX = e.clientX; baseX = x;
    row.setAttribute('data-dragging', '');
    surface.style.transition = 'none';
    try { surface.setPointerCapture(e.pointerId); } catch {}
  });
  surface.addEventListener('pointermove', e => {
    if (!dragging) return;
    let nx = baseX + (e.clientX - startX);
    if (nx > 0) nx *= 0.3;
    const C = commitPoint();
    if (-nx > C) nx = -(C + (-nx - C) * 0.35);
    x = nx;
    surface.style.transform = `translateX(${x}px)`;
  });
  surface.addEventListener('pointerup', () => {
    if (!dragging) return;
    const ex = -x, C = commitPoint();
    if (ex >= C) { settle(-row.offsetWidth - 40, true); doDelete(); }
    else if (ex > D / 2) settle(-D);
    else settle(0);
  });
  surface.addEventListener('pointercancel', () => { if (dragging) settle(open ? -D : 0); });

  const flag = row.querySelector('[data-act="flag"]');
  if (flag) flag.addEventListener('click', () => {
    settle(0);
    toast('🚩 Flagged for review', 'Saved for your next agent check-in');
  });
  const del = row.querySelector('[data-act="delete"]');
  if (del) del.addEventListener('click', () => {
    settle(-row.offsetWidth - 40, true);
    doDelete();
  });
});

// ---- 14. Page loader ----
const pageLoader = document.getElementById('pageLoader');
if (pageLoader) {
  pageLoader.querySelectorAll('.ll-run .ll-cell[data-unit]').forEach(c => {
    c.style.animationDelay = (Number(c.dataset.unit) * 90 * 1.2).toFixed(0) + 'ms';
  });
  const timerEl = pageLoader.querySelector('.ll-timer');
  const t0 = performance.now();
  const tick = setInterval(() => {
    timerEl.textContent = ((performance.now() - t0) / 1000).toFixed(1) + 's';
  }, 100);

  function finish() {
    clearInterval(tick);
    timerEl.textContent = ((performance.now() - t0) / 1000).toFixed(1) + 's';
    pageLoader.dataset.status = 'done';
    setTimeout(() => {
      pageLoader.classList.add('ll-gone');
      setTimeout(() => pageLoader.remove(), 450);
    }, 550);
  }
  window.addEventListener('load', finish);
  setTimeout(finish, 8000);
}
