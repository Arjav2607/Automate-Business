"""
database.py — everything related to SQLite lives here.
SQLite is just a single file (business.db). No server needed.
"""
import sqlite3

DB_PATH = "business.db"


def get_db():
    """Open a connection. row_factory=Row lets you use row["column_name"]."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables if they don't exist, and add sample products on first run."""
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        name TEXT,
        stock INTEGER DEFAULT 0,
        price REAL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY,
        agent_id TEXT,
        customer TEXT,
        product TEXT,
        quantity INTEGER DEFAULT 1,
        amount REAL DEFAULT 0,
        status TEXT DEFAULT 'placed',
        phone TEXT,              -- optional, set on manual orders
        email TEXT,              -- optional
        location TEXT,           -- optional
        note TEXT,               -- optional description
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY,
        agent_id TEXT,
        customer TEXT,
        sender TEXT,                -- 'agent' or 'customer'
        message TEXT,
        audio_url TEXT,             -- set when the message is a voice note
        duration INTEGER DEFAULT 0, -- voice note length in seconds
        flagged INTEGER DEFAULT 0,  -- owner flagged it for review
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS approvals (
        id INTEGER PRIMARY KEY,
        agent_id TEXT,
        type TEXT,                  -- e.g. 'discount', 'out_of_stock', 'unknown_question'
        summary TEXT,               -- short line for the owner, e.g. "Give 15% discount?"
        context TEXT,               -- longer explanation / full chat snippet
        resume_url TEXT,            -- n8n webhook URL to call when owner decides
        status TEXT DEFAULT 'pending',   -- pending / approved / rejected
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        decided_at TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY,
        customer TEXT UNIQUE,           -- one feedback row per customer
        rating INTEGER DEFAULT 0,       -- 0-5 stars
        note TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    # Migrate older databases: add voice-message columns if missing
    cols = [r[1] for r in conn.execute("PRAGMA table_info(conversations)")]
    if "audio_url" not in cols:
        conn.execute("ALTER TABLE conversations ADD COLUMN audio_url TEXT")
        conn.execute("ALTER TABLE conversations ADD COLUMN duration INTEGER DEFAULT 0")
    if "flagged" not in cols:
        conn.execute("ALTER TABLE conversations ADD COLUMN flagged INTEGER DEFAULT 0")
    # migrate older databases: manual-order detail columns
    ocols = [r[1] for r in conn.execute("PRAGMA table_info(orders)")]
    for col in ("phone", "email", "location", "note"):
        if col not in ocols:
            conn.execute(f"ALTER TABLE orders ADD COLUMN {col} TEXT")
    # Sample products so the pages aren't empty on first run
    if conn.execute("SELECT COUNT(*) c FROM products").fetchone()["c"] == 0:
        conn.executemany(
            "INSERT INTO products (name, stock, price) VALUES (?,?,?)",
            [("Wireless Mouse", 12, 499),
             ("Keyboard", 4, 899),
             ("USB-C Hub", 25, 1299),
             ("Webcam", 3, 2499)])
    conn.commit()
    conn.close()
